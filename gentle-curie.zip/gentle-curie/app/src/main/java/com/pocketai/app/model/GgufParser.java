package com.pocketai.app.model;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class GgufParser {
    // Magic: "GGUF" in ASCII -> 0x46554747 in little-endian uint32
    public static final byte[] GGUF_MAGIC = new byte[]{'G', 'G', 'U', 'F'};
    private static final int MAX_KEY_LENGTH = 1024;
    private static final int MAX_STRING_LENGTH = 65536;
    private static final long MAX_METADATA_BYTES = 32 * 1024 * 1024; // 32 MB cap
    private static final long MAX_ARRAY_ELEMENTS = 10_000_000L;

    public static final int TYPE_UINT8 = 0;
    public static final int TYPE_INT8 = 1;
    public static final int TYPE_UINT16 = 2;
    public static final int TYPE_INT16 = 3;
    public static final int TYPE_UINT32 = 4;
    public static final int TYPE_INT32 = 5;
    public static final int TYPE_FLOAT32 = 6;
    public static final int TYPE_BOOL = 7;
    public static final int TYPE_STRING = 8;
    public static final int TYPE_ARRAY = 9;
    public static final int TYPE_UINT64 = 10;
    public static final int TYPE_INT64 = 11;
    public static final int TYPE_FLOAT64 = 12;

    public static GgufMetadata parse(InputStream rawInput, long fileSizeBytes, String fileName) throws IOException {
        BufferedInputStream in = new BufferedInputStream(rawInput, 65536);

        // 1. Validate magic bytes
        byte[] magic = new byte[4];
        readFully(in, magic, 0, 4);
        if (magic[0] != GGUF_MAGIC[0] || magic[1] != GGUF_MAGIC[1] ||
            magic[2] != GGUF_MAGIC[2] || magic[3] != GGUF_MAGIC[3]) {
            String found = new String(magic, StandardCharsets.ISO_8859_1);
            throw new GgufParseException("Invalid GGUF header: expected magic 'GGUF', but found '" + found + "'");
        }

        // 2. Read version
        int version = readInt32LE(in);
        if (version < 1 || version > 10) {
            throw new GgufParseException("Unsupported GGUF version: " + version + " (supported: 1-10)");
        }

        // 3. Tensor count & KV count
        long tensorCount = readInt64LE(in);
        long kvCount = readInt64LE(in);

        if (tensorCount < 0) {
            throw new GgufParseException("Corrupt GGUF file: negative tensor count (" + tensorCount + ")");
        }
        if (kvCount < 0 || kvCount > 100000) {
            throw new GgufParseException("Corrupt GGUF file: invalid metadata KV count (" + kvCount + ")");
        }

        Map<String, Object> metadata = new HashMap<>();
        long bytesRead = 24; // 4 magic + 4 version + 8 tensorCount + 8 kvCount

        // 4. Parse KV entries
        for (long i = 0; i < kvCount; i++) {
            if (bytesRead > MAX_METADATA_BYTES) {
                // Safety cutoff to avoid excessive memory / runaway corrupt stream
                break;
            }

            // Key length
            long keyLen = readInt64LE(in);
            bytesRead += 8;
            if (keyLen < 0 || keyLen > MAX_KEY_LENGTH) {
                throw new GgufParseException("Corrupt GGUF key length: " + keyLen);
            }

            byte[] keyBytes = new byte[(int) keyLen];
            readFully(in, keyBytes, 0, (int) keyLen);
            bytesRead += keyLen;
            String key = new String(keyBytes, StandardCharsets.UTF_8);

            // Value type
            int valType = readInt32LE(in);
            bytesRead += 4;

            // Read / skip value
            long valBytes = parseValue(in, valType, key, metadata);
            bytesRead += valBytes;
        }

        // Extract metadata fields
        String architecture = (String) metadata.get("general.architecture");
        if (architecture == null) architecture = "unknown";

        String modelName = (String) metadata.get("general.name");
        if (modelName == null || modelName.trim().isEmpty()) {
            modelName = stripExtension(fileName);
        }

        String quantization = null;
        Object fileTypeObj = metadata.get("general.file_type");
        if (fileTypeObj instanceof Number) {
            quantization = formatFileType(((Number) fileTypeObj).intValue());
        }
        if (quantization == null || quantization.equalsIgnoreCase("unknown")) {
            quantization = detectQuantizationFromFilename(fileName);
        }

        long contextLength = 0L;
        Object ctxObj = metadata.get(architecture + ".context_length");
        if (ctxObj == null) {
            ctxObj = metadata.get("general.context_length");
        }
        if (ctxObj instanceof Number) {
            contextLength = ((Number) ctxObj).longValue();
        }

        return new GgufMetadata(
                modelName,
                architecture,
                quantization,
                version,
                tensorCount,
                kvCount,
                contextLength,
                fileSizeBytes,
                fileName
        );
    }

    private static long parseValue(
            BufferedInputStream in,
            int valType,
            String key,
            Map<String, Object> metadata) throws IOException {

        switch (valType) {
            case TYPE_UINT8: {
                int b = in.read();
                if (b < 0) throw new EOFException();
                if (isTargetKey(key)) metadata.put(key, b);
                return 1;
            }
            case TYPE_INT8: {
                int b = in.read();
                if (b < 0) throw new EOFException();
                if (isTargetKey(key)) metadata.put(key, (byte) b);
                return 1;
            }
            case TYPE_UINT16:
            case TYPE_INT16: {
                short s = readInt16LE(in);
                if (isTargetKey(key)) metadata.put(key, s);
                return 2;
            }
            case TYPE_UINT32:
            case TYPE_INT32: {
                int v = readInt32LE(in);
                if (isTargetKey(key)) metadata.put(key, v);
                return 4;
            }
            case TYPE_FLOAT32: {
                int bits = readInt32LE(in);
                float f = Float.intBitsToFloat(bits);
                if (isTargetKey(key)) metadata.put(key, f);
                return 4;
            }
            case TYPE_BOOL: {
                int b = in.read();
                if (b < 0) throw new EOFException();
                if (isTargetKey(key)) metadata.put(key, b != 0);
                return 1;
            }
            case TYPE_STRING: {
                long len = readInt64LE(in);
                if (len < 0 || len > 10_000_000L) {
                    throw new GgufParseException("Invalid string length: " + len);
                }
                if (isTargetKey(key) && len <= MAX_STRING_LENGTH) {
                    byte[] buf = new byte[(int) len];
                    readFully(in, buf, 0, (int) len);
                    metadata.put(key, new String(buf, StandardCharsets.UTF_8));
                } else {
                    skipFully(in, len);
                }
                return 8 + len;
            }
            case TYPE_ARRAY: {
                int elemType = readInt32LE(in);
                long elemCount = readInt64LE(in);
                if (elemCount < 0 || elemCount > MAX_ARRAY_ELEMENTS) {
                    throw new GgufParseException("Invalid array element count: " + elemCount);
                }
                long arrayBytes = 4 + 8;
                if (elemType == TYPE_STRING) {
                    for (long j = 0; j < elemCount; j++) {
                        long sLen = readInt64LE(in);
                        skipFully(in, sLen);
                        arrayBytes += 8 + sLen;
                    }
                } else {
                    int elemSize = getFixedTypeSize(elemType);
                    long totalBytes = elemCount * elemSize;
                    skipFully(in, totalBytes);
                    arrayBytes += totalBytes;
                }
                return arrayBytes;
            }
            case TYPE_UINT64:
            case TYPE_INT64: {
                long l = readInt64LE(in);
                if (isTargetKey(key)) metadata.put(key, l);
                return 8;
            }
            case TYPE_FLOAT64: {
                long bits = readInt64LE(in);
                double d = Double.longBitsToDouble(bits);
                if (isTargetKey(key)) metadata.put(key, d);
                return 8;
            }
            default:
                throw new GgufParseException("Unknown GGUF value type: " + valType);
        }
    }

    private static boolean isTargetKey(String key) {
        return key.startsWith("general.") ||
               key.endsWith(".context_length") ||
               key.endsWith(".block_count") ||
               key.endsWith(".embedding_length");
    }

    private static int getFixedTypeSize(int type) throws GgufParseException {
        switch (type) {
            case TYPE_UINT8:
            case TYPE_INT8:
            case TYPE_BOOL:
                return 1;
            case TYPE_UINT16:
            case TYPE_INT16:
                return 2;
            case TYPE_UINT32:
            case TYPE_INT32:
            case TYPE_FLOAT32:
                return 4;
            case TYPE_UINT64:
            case TYPE_INT64:
            case TYPE_FLOAT64:
                return 8;
            default:
                throw new GgufParseException("Invalid array element type: " + type);
        }
    }

    public static String formatFileType(int fileType) {
        switch (fileType) {
            case 0: return "F32";
            case 1: return "F16";
            case 2: return "Q4_0";
            case 3: return "Q4_1";
            case 7: return "Q8_0";
            case 8: return "Q5_0";
            case 9: return "Q5_1";
            case 10: return "Q2_K";
            case 11: return "Q3_K_S";
            case 12: return "Q3_K_M";
            case 13: return "Q3_K_L";
            case 14: return "Q4_K_S";
            case 15: return "Q4_K_M";
            case 16: return "Q5_K_S";
            case 17: return "Q5_K_M";
            case 18: return "Q6_K";
            case 19: return "IQ2_XXS";
            case 20: return "IQ2_XS";
            case 21: return "IQ3_XXS";
            case 22: return "IQ1_S";
            case 23: return "IQ4_NL";
            case 24: return "IQ3_S";
            case 25: return "IQ2_S";
            case 26: return "IQ4_XS";
            case 27: return "IQ1_M";
            case 28: return "BF16";
            default: return "Type " + fileType;
        }
    }

    public static String detectQuantizationFromFilename(String fileName) {
        if (fileName == null) return "unknown";
        String upper = fileName.toUpperCase(Locale.ROOT);
        String[] quants = {
            "Q4_K_M", "Q4_K_S", "Q5_K_M", "Q5_K_S", "Q6_K", "Q8_0",
            "Q4_0", "Q4_1", "Q5_0", "Q5_1", "Q2_K", "Q3_K_L", "Q3_K_M", "Q3_K_S",
            "IQ4_NL", "IQ4_XS", "IQ3_M", "IQ3_S", "IQ3_XXS", "IQ2_M", "IQ2_S", "IQ2_XS", "IQ2_XXS", "IQ1_M", "IQ1_S",
            "BF16", "F16", "F32"
        };
        for (String q : quants) {
            if (upper.contains(q)) return q;
        }
        return "unknown";
    }

    private static String stripExtension(String fileName) {
        if (fileName == null) return "Model";
        int dot = fileName.lastIndexOf('.');
        if (dot > 0) {
            return fileName.substring(0, dot);
        }
        return fileName;
    }

    private static short readInt16LE(InputStream in) throws IOException {
        int b0 = in.read();
        int b1 = in.read();
        if ((b0 | b1) < 0) throw new EOFException("Unexpected EOF reading int16");
        return (short) ((b1 << 8) | b0);
    }

    private static int readInt32LE(InputStream in) throws IOException {
        int b0 = in.read();
        int b1 = in.read();
        int b2 = in.read();
        int b3 = in.read();
        if ((b0 | b1 | b2 | b3) < 0) throw new EOFException("Unexpected EOF reading int32");
        return (b3 << 24) | (b2 << 16) | (b1 << 8) | b0;
    }

    private static long readInt64LE(InputStream in) throws IOException {
        byte[] b = new byte[8];
        readFully(in, b, 0, 8);
        return (((long) b[7] & 0xFF) << 56) |
               (((long) b[6] & 0xFF) << 48) |
               (((long) b[5] & 0xFF) << 40) |
               (((long) b[4] & 0xFF) << 32) |
               (((long) b[3] & 0xFF) << 24) |
               (((long) b[2] & 0xFF) << 16) |
               (((long) b[1] & 0xFF) << 8)  |
               ((long) b[0] & 0xFF);
    }

    private static void readFully(InputStream in, byte[] buffer, int offset, int length) throws IOException {
        int read = 0;
        while (read < length) {
            int count = in.read(buffer, offset + read, length - read);
            if (count < 0) {
                throw new EOFException("Unexpected EOF while reading " + length + " bytes (got " + read + ")");
            }
            read += count;
        }
    }

    private static void skipFully(InputStream in, long bytes) throws IOException {
        long remaining = bytes;
        while (remaining > 0) {
            long skipped = in.skip(remaining);
            if (skipped <= 0) {
                if (in.read() == -1) {
                    throw new EOFException("Unexpected EOF while skipping " + bytes + " bytes");
                }
                remaining--;
            } else {
                remaining -= skipped;
            }
        }
    }
}
