package com.pocketai.app.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.Locale;

public class ModelRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    public final String id;
    public final String uriString;
    public final String fileName;
    public final String modelName;
    public final String architecture;
    public final String quantization;
    public final int version;
    public final long tensorCount;
    public final long kvCount;
    public final long contextLength;
    public final long fileSizeBytes;
    public final long importTimestamp;

    public ModelRecord(
            String id,
            String uriString,
            String fileName,
            String modelName,
            String architecture,
            String quantization,
            int version,
            long tensorCount,
            long kvCount,
            long contextLength,
            long fileSizeBytes,
            long importTimestamp) {
        this.id = id;
        this.uriString = uriString;
        this.fileName = fileName;
        this.modelName = modelName;
        this.architecture = architecture;
        this.quantization = quantization;
        this.version = version;
        this.tensorCount = tensorCount;
        this.kvCount = kvCount;
        this.contextLength = contextLength;
        this.fileSizeBytes = fileSizeBytes;
        this.importTimestamp = importTimestamp;
    }

    public static ModelRecord fromMetadata(String id, String uriString, GgufMetadata meta) {
        return new ModelRecord(
                id,
                uriString,
                meta.fileName,
                meta.modelName,
                meta.architecture,
                meta.quantization,
                meta.version,
                meta.tensorCount,
                meta.kvCount,
                meta.contextLength,
                meta.fileSizeBytes,
                System.currentTimeMillis()
        );
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("uriString", uriString);
        obj.put("fileName", fileName);
        obj.put("modelName", modelName);
        obj.put("architecture", architecture);
        obj.put("quantization", quantization);
        obj.put("version", version);
        obj.put("tensorCount", tensorCount);
        obj.put("kvCount", kvCount);
        obj.put("contextLength", contextLength);
        obj.put("fileSizeBytes", fileSizeBytes);
        obj.put("importTimestamp", importTimestamp);
        return obj;
    }

    public static ModelRecord fromJson(JSONObject obj) throws JSONException {
        return new ModelRecord(
                obj.getString("id"),
                obj.getString("uriString"),
                obj.optString("fileName", "Unknown"),
                obj.optString("modelName", "Unknown"),
                obj.optString("architecture", "Unknown"),
                obj.optString("quantization", "Unknown"),
                obj.optInt("version", 0),
                obj.optLong("tensorCount", 0L),
                obj.optLong("kvCount", 0L),
                obj.optLong("contextLength", 0L),
                obj.optLong("fileSizeBytes", 0L),
                obj.optLong("importTimestamp", 0L)
        );
    }

    public String getFormattedSize() {
        if (fileSizeBytes <= 0) return "Unknown size";
        double mb = fileSizeBytes / (1024.0 * 1024.0);
        if (mb < 1024.0) {
            return String.format(Locale.US, "%.1f MB", mb);
        }
        double gb = mb / 1024.0;
        return String.format(Locale.US, "%.2f GB", gb);
    }
}
