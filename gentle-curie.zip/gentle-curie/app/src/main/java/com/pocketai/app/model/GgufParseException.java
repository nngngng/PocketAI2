package com.pocketai.app.model;

import java.io.IOException;

public class GgufParseException extends IOException {
    public GgufParseException(String message) {
        super(message);
    }

    public GgufParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
