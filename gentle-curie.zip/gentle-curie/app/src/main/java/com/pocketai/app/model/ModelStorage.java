package com.pocketai.app.model;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ModelStorage {
    private static final String PREF_NAME = "pocketai_models";
    private static final String KEY_MODELS = "imported_models_json";
    private static final String KEY_SELECTED_ID = "selected_model_id";

    private final SharedPreferences prefs;

    public ModelStorage(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public synchronized List<ModelRecord> getModels() {
        List<ModelRecord> list = new ArrayList<>();
        String raw = prefs.getString(KEY_MODELS, null);
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                list.add(ModelRecord.fromJson(obj));
            }
        } catch (JSONException ignored) {
        }
        return list;
    }

    public synchronized void saveModel(ModelRecord model) {
        List<ModelRecord> models = getModels();
        int existingIndex = -1;
        for (int i = 0; i < models.size(); i++) {
            if (models.get(i).uriString.equals(model.uriString) || models.get(i).id.equals(model.id)) {
                existingIndex = i;
                break;
            }
        }
        if (existingIndex >= 0) {
            models.set(existingIndex, model);
        } else {
            models.add(model);
        }
        persistModels(models);
    }

    public synchronized void removeModel(String modelId) {
        List<ModelRecord> models = getModels();
        models.removeIf(m -> m.id.equals(modelId));
        persistModels(models);

        String selectedId = getSelectedModelId();
        if (modelId != null && modelId.equals(selectedId)) {
            setSelectedModelId(null);
        }
    }

    public synchronized String getSelectedModelId() {
        return prefs.getString(KEY_SELECTED_ID, null);
    }

    public synchronized void setSelectedModelId(String modelId) {
        prefs.edit().putString(KEY_SELECTED_ID, modelId).apply();
    }

    public synchronized ModelRecord getSelectedModel() {
        String selectedId = getSelectedModelId();
        if (selectedId == null) return null;
        for (ModelRecord m : getModels()) {
            if (m.id.equals(selectedId)) return m;
        }
        return null;
    }

    private void persistModels(List<ModelRecord> models) {
        JSONArray arr = new JSONArray();
        for (ModelRecord m : models) {
            try {
                arr.put(m.toJson());
            } catch (JSONException ignored) {
            }
        }
        prefs.edit().putString(KEY_MODELS, arr.toString()).apply();
    }
}
