package com.pocketai.app

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.pocketai.app.model.GgufMetadata
import com.pocketai.app.model.GgufParser
import com.pocketai.app.model.ModelRecord
import com.pocketai.app.model.ModelStorage
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var ramText: TextView
    private lateinit var storageText: TextView
    private lateinit var batteryText: TextView
    private lateinit var cpuText: TextView

    private lateinit var serverTitle: TextView
    private lateinit var serverSubtitle: TextView
    private lateinit var modelListContainer: LinearLayout
    private lateinit var modelStorage: ModelStorage

    private val background = Color.rgb(10, 14, 22)
    private val panel = Color.rgb(22, 30, 42)
    private val panelSecondary = Color.rgb(16, 22, 32)
    private val white = Color.rgb(240, 244, 255)
    private val muted = Color.rgb(166, 180, 200)
    private val blue = Color.rgb(121, 177, 255)
    private val green = Color.rgb(103, 218, 163)
    private val amber = Color.rgb(255, 183, 77)
    private val red = Color.rgb(255, 110, 110)

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(this, "Model import cancelled", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        importGgufModel(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelStorage = ModelStorage(this)
        buildDashboard()
        refreshDeviceInfo()
        renderModelList()
        updateServerStatus()
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(22, 28, 22, 24)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(title("PocketAI", 30f, white))
        content.addView(subtitle("YOUR PHONE. YOUR MODELS. YOUR API."))
        content.addView(space(22))

        // SERVER STATUS
        content.addView(section("SERVER STATUS"))
        content.addView(card {
            serverTitle = title("Offline", 25f, white)
            serverSubtitle = subtitle("No model selected. Import and select a GGUF model below.")
            addView(serverTitle)
            addView(space(6))
            addView(serverSubtitle)
        })

        content.addView(space(20))

        // DEVICE RESOURCES (Stage 1 Diagnostics)
        content.addView(section("DEVICE RESOURCES"))
        content.addView(card {
            addView(subtitle("AVAILABLE RAM"))
            ramText = title("--", 24f, blue)
            addView(ramText)
            addView(space(12))

            addView(subtitle("STORAGE"))
            storageText = title("--", 18f, white)
            addView(storageText)
            addView(space(12))

            addView(subtitle("BATTERY"))
            batteryText = title("--", 18f, green)
            addView(batteryText)
            addView(space(12))

            addView(subtitle("CPU / PLATFORM"))
            cpuText = title("--", 16f, white)
            addView(cpuText)
            addView(space(12))

            val refresh = Button(this@MainActivity).apply {
                text = "Refresh device information"
                setOnClickListener {
                    refreshDeviceInfo()
                    Toast.makeText(this@MainActivity, "Device information updated", Toast.LENGTH_SHORT).show()
                }
            }
            addView(refresh)
        })

        content.addView(space(20))

        // MODEL MANAGER (Stage 2)
        content.addView(section("MODEL MANAGER"))
        content.addView(card {
            val importButton = Button(this@MainActivity).apply {
                text = "Import GGUF Model from Storage"
                setOnClickListener {
                    try {
                        openDocumentLauncher.launch(arrayOf("*/*"))
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Failed to launch file picker: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            addView(importButton)
            addView(space(12))

            modelListContainer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            addView(modelListContainer)
        })

        content.addView(space(20))

        // QUICK ACTIONS
        content.addView(section("QUICK ACTIONS"))
        content.addView(card {
            addView(title("Local AI Chat", 18f, white))
            addView(subtitle("Coming in Stage 4."))
            addView(space(10))
            addView(title("API Manager", 18f, white))
            addView(subtitle("HTTP server scheduled for Stage 5."))
        })

        content.addView(space(26))
        content.addView(subtitle("PocketAI  •  STAGE 2: MODEL MANAGER"))

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun importGgufModel(uri: Uri) {
        // 1. Take persistable permissions
        try {
            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (e: SecurityException) {
            // Non-persistable provider; proceed with direct access
        }

        // 2. Query file metadata from SAF provider
        var fileName = "model.gguf"
        var fileSizeBytes = 0L
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) cursor.getString(nameIndex)?.let { fileName = it }
                    if (sizeIndex != -1) fileSizeBytes = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            uri.lastPathSegment?.let { fileName = it }
        }

        // 3. Open stream and safely parse GGUF header without full RAM load
        val metadata: GgufMetadata = try {
            val inputStream = contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Unable to open input stream for selected file.")
            inputStream.use { stream ->
                GgufParser.parse(stream, fileSizeBytes, fileName)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "GGUF validation failed: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // 4. Persist model record and auto-select
        val record = ModelRecord.fromMetadata(UUID.randomUUID().toString(), uri.toString(), metadata)
        modelStorage.saveModel(record)
        modelStorage.selectedModelId = record.id

        renderModelList()
        updateServerStatus()
        Toast.makeText(this, "Imported ${metadata.modelName} successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun renderModelList() {
        modelListContainer.removeAllViews()
        val models = modelStorage.models
        val selectedId = modelStorage.selectedModelId

        if (models.isEmpty()) {
            val emptyNotice = subtitle("No GGUF models imported yet.\nTap 'Import GGUF Model from Storage' to select a .gguf file from device storage.")
            modelListContainer.addView(emptyNotice)
            return
        }

        for (m in models) {
            val isSelected = (m.id == selectedId)
            val isAccessible = checkUriAccessibility(Uri.parse(m.uriString))

            val modelCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(panelSecondary)
                setPadding(14, 14, 14, 14)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 10
                }
            }

            // Model Name & File Name
            modelCard.addView(title(m.modelName, 17f, white))
            modelCard.addView(subtitle(m.fileName))
            modelCard.addView(space(6))

            // Metadata Badges
            val metaInfo = "${m.architecture.uppercase()} • GGUF v${m.version} • ${m.quantization} • ${m.formattedSize}"
            modelCard.addView(subtitle(metaInfo))

            // Context & Tensors
            val ctxStr = if (m.contextLength > 0) "${m.contextLength} ctx" else "unknown ctx"
            val tensorsStr = if (m.tensorCount > 0) "${m.tensorCount} tensors" else "tensors unlisted"
            modelCard.addView(subtitle("$tensorsStr • $ctxStr"))

            if (!isAccessible) {
                modelCard.addView(space(4))
                modelCard.addView(TextView(this).apply {
                    text = "File inaccessible (moved, deleted, or permission revoked)"
                    textSize = 12f
                    setTextColor(red)
                })
            }

            modelCard.addView(space(8))

            // Action Buttons Row
            val buttonRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            if (isSelected) {
                val activeBadge = TextView(this).apply {
                    text = "ACTIVE MODEL"
                    textSize = 13f
                    setTextColor(green)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 0, 16, 0)
                }
                buttonRow.addView(activeBadge)
            } else {
                val selectBtn = Button(this).apply {
                    text = "Set Active"
                    isEnabled = isAccessible
                    setOnClickListener {
                        modelStorage.selectedModelId = m.id
                        renderModelList()
                        updateServerStatus()
                        Toast.makeText(this@MainActivity, "Active model: ${m.modelName}", Toast.LENGTH_SHORT).show()
                    }
                }
                buttonRow.addView(selectBtn)
            }

            val removeBtn = Button(this).apply {
                text = "Remove"
                setTextColor(red)
                setOnClickListener {
                    removeModel(m)
                }
            }
            buttonRow.addView(removeBtn)

            modelCard.addView(buttonRow)
            modelListContainer.addView(modelCard)
        }
    }

    private fun removeModel(model: ModelRecord) {
        try {
            contentResolver.releasePersistableUriPermission(
                Uri.parse(model.uriString),
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            // Ignore if permission release is unsupported
        }
        modelStorage.removeModel(model.id)
        renderModelList()
        updateServerStatus()
        Toast.makeText(this, "Removed ${model.modelName}", Toast.LENGTH_SHORT).show()
    }

    private fun checkUriAccessibility(uri: Uri): Boolean {
        return try {
            contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun updateServerStatus() {
        val selected = modelStorage.selectedModel
        if (selected != null) {
            serverTitle.text = "Model Ready"
            serverTitle.setTextColor(green)
            serverSubtitle.text = "Active: ${selected.modelName} (${selected.architecture} • ${selected.quantization} • ${selected.formattedSize})\nReady for Stage 3 local inference engine."
        } else {
            serverTitle.text = "Offline"
            serverTitle.setTextColor(white)
            serverSubtitle.text = "No model selected. Import and select a GGUF model below."
        }
    }

    private fun refreshDeviceInfo() {
        val manager = getSystemService(ActivityManager::class.java) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)

        val totalRamMb = memory.totalMem / (1024L * 1024L)
        val availableRamMb = memory.availMem / (1024L * 1024L)
        ramText.text = "${availableRamMb} MB free / ${totalRamMb} MB total"

        val storageTextValue = buildStorageSummary()
        storageText.text = storageTextValue

        batteryText.text = readBatteryStatus()
        cpuText.text = buildCpuSummary()
    }

    private fun buildStorageSummary(): String {
        val appDir = filesDir
        val statFs = StatFs(appDir.absolutePath)

        val totalBytes = statFs.blockCountLong * statFs.blockSizeLong
        val availableBytes = statFs.availableBytes
        val usedBytes = totalBytes - availableBytes

        val totalGb = totalBytes / (1024L * 1024L * 1024L)
        val usedGb = usedBytes / (1024L * 1024L * 1024L)
        return "${usedGb} GB used / ${totalGb} GB total"
    }

    private fun readBatteryStatus(): String {
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1

        return if (level >= 0 && scale > 0) {
            val percent = (level * 100f / scale).toInt()
            "$percent% battery"
        } else {
            "Battery unavailable"
        }
    }

    private fun buildCpuSummary(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"
        return "Android ${Build.VERSION.RELEASE} • ${abi}"
    }

    private fun title(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.START
    }

    private fun subtitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(muted)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(blue)
        setPadding(0, 4, 0, 10)
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            1,
            (height * resources.displayMetrics.density).toInt()
        )
    }

    private fun card(content: LinearLayout.() -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(panel)
        setPadding(16, 18, 16, 18)
        content()
    }.also {
        it.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = 8
        }
    }
}
