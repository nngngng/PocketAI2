package com.pocketai.app.model;

import java.io.Serializable;
import java.util.Locale;

public class GgufMetadata implements Serializable {
    private static final long serialVersionUID = 1L;

    public final String modelName;
    public final String architecture;
    public final String quantization;
    public final int version;
    public final long tensorCount;
    public final long kvCount;
    public final long contextLength;
    public final long fileSizeBytes;
    public final String fileName;

    public GgufMetadata(
            String modelName,
            String architecture,
            String quantization,
            int version,
            long tensorCount,
            long kvCount,
            long contextLength,
            long fileSizeBytes,
            String fileName) {
        this.modelName = (modelName != null && !modelName.trim().isEmpty()) ? modelName.trim() : fileName;
        this.architecture = (architecture != null && !architecture.trim().isEmpty()) ? architecture.trim() : "unknown";
        this.quantization = (quantization != null && !quantization.trim().isEmpty()) ? quantization.trim() : "unknown";
        this.version = version;
        this.tensorCount = tensorCount;
        this.kvCount = kvCount;
        this.contextLength = contextLength;
        this.fileSizeBytes = fileSizeBytes;
        this.fileName = fileName;
    }

    public String getFormattedSize() {
        if (fileSizeBytes <= 0) return "Unknown size";
        double mb = fileSizeBytes / (1024.0 * 1024.0);
        if (mb < 1024.0) {
            return String.format(Locale.US, "%.1f MB", mb);
        }
        double gb = mb / 1024.0;
        return String.format(Locale.US, "%.2f GB", gb);
    }
}
