package com.pocketai.app;

import com.pocketai.app.model.GgufMetadata;
import com.pocketai.app.model.GgufParseException;
import com.pocketai.app.model.GgufParser;

import org.junit.Assert;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class GgufParserTest {

    private void writeInt16LE(ByteArrayOutputStream out, short val) {
        out.write(val & 0xFF);
        out.write((val >> 8) & 0xFF);
    }

    private void writeInt32LE(ByteArrayOutputStream out, int val) {
        out.write(val & 0xFF);
        out.write((val >> 8) & 0xFF);
        out.write((val >> 16) & 0xFF);
        out.write((val >> 24) & 0xFF);
    }

    private void writeInt64LE(ByteArrayOutputStream out, long val) {
        for (int i = 0; i < 8; i++) {
            out.write((int) ((val >> (8 * i)) & 0xFF));
        }
    }

    private void writeString(ByteArrayOutputStream out, String str) throws IOException {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        writeInt64LE(out, bytes.length);
        out.write(bytes);
    }

    @Test
    public void testValidGgufV3Parsing() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        // Magic: "GGUF"
        out.write(new byte[]{'G', 'G', 'U', 'F'});
        // Version: 3
        writeInt32LE(out, 3);
        // Tensor count: 291
        writeInt64LE(out, 291L);
        // KV count: 4
        writeInt64LE(out, 4L);

        // KV 1: general.architecture = "llama"
        writeString(out, "general.architecture");
        writeInt32LE(out, GgufParser.TYPE_STRING);
        writeString(out, "llama");

        // KV 2: general.name = "Llama-3.2-1B-Instruct"
        writeString(out, "general.name");
        writeInt32LE(out, GgufParser.TYPE_STRING);
        writeString(out, "Llama-3.2-1B-Instruct");

        // KV 3: general.file_type = 15 (Q4_K_M)
        writeString(out, "general.file_type");
        writeInt32LE(out, GgufParser.TYPE_UINT32);
        writeInt32LE(out, 15);

        // KV 4: llama.context_length = 8192
        writeString(out, "llama.context_length");
        writeInt32LE(out, GgufParser.TYPE_UINT64);
        writeInt64LE(out, 8192L);

        byte[] ggufBytes = out.toByteArray();
        ByteArrayInputStream in = new ByteArrayInputStream(ggufBytes);

        GgufMetadata meta = GgufParser.parse(in, 1_250_000_000L, "llama-3.2.gguf");

        Assert.assertNotNull(meta);
        Assert.assertEquals("Llama-3.2-1B-Instruct", meta.modelName);
        Assert.assertEquals("llama", meta.architecture);
        Assert.assertEquals("Q4_K_M", meta.quantization);
        Assert.assertEquals(3, meta.version);
        Assert.assertEquals(291L, meta.tensorCount);
        Assert.assertEquals(4L, meta.kvCount);
        Assert.assertEquals(8192L, meta.contextLength);
        Assert.assertEquals(1_250_000_000L, meta.fileSizeBytes);
        Assert.assertEquals("1.16 GB", meta.getFormattedSize());
    }

    @Test(expected = GgufParseException.class)
    public void testInvalidMagicBytesRejected() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{'B', 'A', 'D', '!'});
        writeInt32LE(out, 3);
        writeInt64LE(out, 10);
        writeInt64LE(out, 0);

        ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        GgufParser.parse(in, 1000L, "corrupt.gguf");
    }

    @Test(expected = GgufParseException.class)
    public void testUnsupportedVersionRejected() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{'G', 'G', 'U', 'F'});
        writeInt32LE(out, 99); // Unsupported version
        writeInt64LE(out, 10);
        writeInt64LE(out, 0);

        ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        GgufParser.parse(in, 1000L, "model.gguf");
    }

    @Test(expected = IOException.class)
    public void testTruncatedHeaderRejected() throws IOException {
        byte[] truncated = new byte[]{'G', 'G', 'U', 'F', 3, 0};
        ByteArrayInputStream in = new ByteArrayInputStream(truncated);
        GgufParser.parse(in, 6L, "truncated.gguf");
    }

    @Test
    public void testQuantizationFallbackFromFilename() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{'G', 'G', 'U', 'F'});
        writeInt32LE(out, 2);
        writeInt64LE(out, 100L);
        writeInt64LE(out, 1L);

        // KV 1: general.architecture = "qwen2"
        writeString(out, "general.architecture");
        writeInt32LE(out, GgufParser.TYPE_STRING);
        writeString(out, "qwen2");

        ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        GgufMetadata meta = GgufParser.parse(in, 500_000_000L, "Qwen2.5-0.5B-Instruct-Q8_0.gguf");

        Assert.assertEquals("Qwen2.5-0.5B-Instruct-Q8_0", meta.modelName);
        Assert.assertEquals("qwen2", meta.architecture);
        Assert.assertEquals("Q8_0", meta.quantization);
        Assert.assertEquals(2, meta.version);
    }

    @Test
    public void testArraySkippingInMetadata() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{'G', 'G', 'U', 'F'});
        writeInt32LE(out, 3);
        writeInt64LE(out, 50L);
        writeInt64LE(out, 2L);

        // KV 1: tokenizer.ggml.tokens (Array of strings)
        writeString(out, "tokenizer.ggml.tokens");
        writeInt32LE(out, GgufParser.TYPE_ARRAY);
        writeInt32LE(out, GgufParser.TYPE_STRING); // element type
        writeInt64LE(out, 3L); // 3 elements
        writeString(out, "token_1");
        writeString(out, "token_2");
        writeString(out, "token_3");

        // KV 2: general.name
        writeString(out, "general.name");
        writeInt32LE(out, GgufParser.TYPE_STRING);
        writeString(out, "TestArrayModel");

        ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        GgufMetadata meta = GgufParser.parse(in, 2048L, "test.gguf");

        Assert.assertEquals("TestArrayModel", meta.modelName);
        Assert.assertEquals(50L, meta.tensorCount);
    }
}
