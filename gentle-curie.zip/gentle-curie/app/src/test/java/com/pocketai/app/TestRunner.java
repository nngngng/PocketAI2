package com.pocketai.app;

import com.pocketai.app.model.GgufMetadata;
import com.pocketai.app.model.GgufParseException;
import com.pocketai.app.model.GgufParser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class TestRunner {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        System.out.println("=== POCKETAI GGUF PARSER TEST SUITE ===");

        runTest("testValidGgufV3Parsing", () -> {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(new byte[]{'G', 'G', 'U', 'F'});
            writeInt32LE(out, 3);
            writeInt64LE(out, 291L);
            writeInt64LE(out, 4L);

            writeString(out, "general.architecture");
            writeInt32LE(out, GgufParser.TYPE_STRING);
            writeString(out, "llama");

            writeString(out, "general.name");
            writeInt32LE(out, GgufParser.TYPE_STRING);
            writeString(out, "Llama-3.2-1B-Instruct");

            writeString(out, "general.file_type");
            writeInt32LE(out, GgufParser.TYPE_UINT32);
            writeInt32LE(out, 15);

            writeString(out, "llama.context_length");
            writeInt32LE(out, GgufParser.TYPE_UINT64);
            writeInt64LE(out, 8192L);

            GgufMetadata meta = GgufParser.parse(new ByteArrayInputStream(out.toByteArray()), 1_250_000_000L, "llama-3.2.gguf");

            assertEquals("Llama-3.2-1B-Instruct", meta.modelName);
            assertEquals("llama", meta.architecture);
            assertEquals("Q4_K_M", meta.quantization);
            assertEquals(3, meta.version);
            assertEquals(291L, meta.tensorCount);
            assertEquals(4L, meta.kvCount);
            assertEquals(8192L, meta.contextLength);
            assertEquals(1_250_000_000L, meta.fileSizeBytes);
            assertEquals("1.16 GB", meta.getFormattedSize());
        });

        runTest("testInvalidMagicBytesRejected", () -> {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(new byte[]{'B', 'A', 'D', '!'});
            writeInt32LE(out, 3);
            writeInt64LE(out, 10);
            writeInt64LE(out, 0);

            boolean caught = false;
            try {
                GgufParser.parse(new ByteArrayInputStream(out.toByteArray()), 1000L, "corrupt.gguf");
            } catch (GgufParseException e) {
                if (e.getMessage().contains("expected magic 'GGUF'")) {
                    caught = true;
                }
            }
            if (!caught) throw new AssertionError("Expected GgufParseException for bad magic bytes");
        });

        runTest("testUnsupportedVersionRejected", () -> {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(new byte[]{'G', 'G', 'U', 'F'});
            writeInt32LE(out, 99);
            writeInt64LE(out, 10);
            writeInt64LE(out, 0);

            boolean caught = false;
            try {
                GgufParser.parse(new ByteArrayInputStream(out.toByteArray()), 1000L, "model.gguf");
            } catch (GgufParseException e) {
                if (e.getMessage().contains("Unsupported GGUF version")) {
                    caught = true;
                }
            }
            if (!caught) throw new AssertionError("Expected GgufParseException for unsupported version");
        });

        runTest("testTruncatedHeaderRejected", () -> {
            byte[] truncated = new byte[]{'G', 'G', 'U', 'F', 3, 0};
            boolean caught = false;
            try {
                GgufParser.parse(new ByteArrayInputStream(truncated), 6L, "truncated.gguf");
            } catch (IOException e) {
                caught = true;
            }
            if (!caught) throw new AssertionError("Expected IOException for truncated header");
        });

        runTest("testQuantizationFallbackFromFilename", () -> {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(new byte[]{'G', 'G', 'U', 'F'});
            writeInt32LE(out, 2);
            writeInt64LE(out, 100L);
            writeInt64LE(out, 1L);

            writeString(out, "general.architecture");
            writeInt32LE(out, GgufParser.TYPE_STRING);
            writeString(out, "qwen2");

            GgufMetadata meta = GgufParser.parse(new ByteArrayInputStream(out.toByteArray()), 500_000_000L, "Qwen2.5-0.5B-Instruct-Q8_0.gguf");

            assertEquals("Qwen2.5-0.5B-Instruct-Q8_0", meta.modelName);
            assertEquals("qwen2", meta.architecture);
            assertEquals("Q8_0", meta.quantization);
            assertEquals(2, meta.version);
        });

        runTest("testArraySkippingInMetadata", () -> {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(new byte[]{'G', 'G', 'U', 'F'});
            writeInt32LE(out, 3);
            writeInt64LE(out, 50L);
            writeInt64LE(out, 2L);

            writeString(out, "tokenizer.ggml.tokens");
            writeInt32LE(out, GgufParser.TYPE_ARRAY);
            writeInt32LE(out, GgufParser.TYPE_STRING);
            writeInt64LE(out, 3L);
            writeString(out, "token_1");
            writeString(out, "token_2");
            writeString(out, "token_3");

            writeString(out, "general.name");
            writeInt32LE(out, GgufParser.TYPE_STRING);
            writeString(out, "TestArrayModel");

            GgufMetadata meta = GgufParser.parse(new ByteArrayInputStream(out.toByteArray()), 2048L, "test.gguf");

            assertEquals("TestArrayModel", meta.modelName);
            assertEquals(50L, meta.tensorCount);
        });

        System.out.println("\nRESULTS: " + passed + " passed, " + failed + " failed.");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void runTest(String name, TestCase test) {
        try {
            test.run();
            System.out.println("  PASS: " + name);
            passed++;
        } catch (Throwable t) {
            System.out.println("  FAIL: " + name + ": " + t.getMessage());
            t.printStackTrace(System.out);
            failed++;
        }
    }

    private interface TestCase {
        void run() throws Throwable;
    }

    private static void assertEquals(Object expected, Object actual) {
        if (expected == null && actual == null) return;
        if (expected != null && expected.equals(actual)) return;
        throw new AssertionError("Expected '" + expected + "', but got '" + actual + "'");
    }

    private static void writeInt32LE(ByteArrayOutputStream out, int val) {
        out.write(val & 0xFF);
        out.write((val >> 8) & 0xFF);
        out.write((val >> 16) & 0xFF);
        out.write((val >> 24) & 0xFF);
    }

    private static void writeInt64LE(ByteArrayOutputStream out, long val) {
        for (int i = 0; i < 8; i++) {
            out.write((int) ((val >> (8 * i)) & 0xFF));
        }
    }

    private static void writeString(ByteArrayOutputStream out, String str) throws IOException {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        writeInt64LE(out, bytes.length);
        out.write(bytes);
    }
}
